package com.centerofminecraft;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public class MobSkinManager {
	private static final Map<class_1299<?>, class_2960> SKINS = new HashMap<>();

	public static void register(class_1299<?> entityType, class_2960 texture) {
		SKINS.put(entityType, texture);
	}

	public static Optional<class_2960> getTexture(class_1299<?> entityType) {
		return Optional.ofNullable(SKINS.get(entityType));
	}
}
