package com.centerofminecraft;

import net.fabricmc.api.ClientModInitializer;
import net.minecraft.class_1299;
import net.minecraft.class_2960;

public class CenterofminecraftClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		MobSkinManager.register(class_1299.field_6046, class_2960.method_60655("centerofminecraft", "textures/entity/creeper.png"));
	}
}