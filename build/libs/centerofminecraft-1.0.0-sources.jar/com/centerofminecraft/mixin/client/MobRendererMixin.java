package com.centerofminecraft.mixin.client;

import com.centerofminecraft.MobSkinManager;
import net.minecraft.class_1308;
import net.minecraft.class_2960;
import net.minecraft.class_927;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_927.class)
public class MobRendererMixin {
	@Inject(method = "getTextureLocation", at = @At("HEAD"), cancellable = true)
	private void centerofminecraft$redirectTexture(class_1308 entity, CallbackInfoReturnable<class_2960> cir) {
		MobSkinManager.getTexture(entity.method_5864()).ifPresent(cir::setReturnValue);
	}
}
